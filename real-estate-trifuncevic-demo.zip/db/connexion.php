<?php 

$host = 'localhost';
$dbname = 'real_estate';
$user = 'tfi_admin';
$password = 'L8_60r3aj';

// Create a new PDO instance
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $password);
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
     
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>